import processing.core.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class wordgame extends PApplet {

//A word game

//const
int bkg = color(240);
int defaultLetterColor = color(180);
int defaultDropSpaceColor = color(220);
PFont f,f2,f3;
float letterSize;
float dropPadding = 10;
HashSet<String> words,wordsUsed;
float damp = .92f;
Random r;
String alphabet;
PVector circleV;


//vars
ArrayList<Letter> letters;
Letter dragged;
DropSpace drop;
DropCircle circle;
boolean isAWord,started,already; //started is used for word display
int points,nextPos;


public void setup(){
 //size(screenWidth,int(screenHeight*.93));
  size(1000,600);
  
  background(bkg);
  //noLoop();
  smooth();
  textAlign(RIGHT);
  noStroke();
  f = loadFont("Helvetica-36.vlw");
  f2 = loadFont("Helvetica-60.vlw");
  f3 = loadFont("Helvetica-120.vlw");
  //f = createFont("Helvetica", 36);
  //f2 = createFont("Helvetica", 60);
  letters = new ArrayList<Letter>();
  r = new Random();
  alphabet = "AAAAAAAAABBCCDDDDEEEEEEEEEEEEFFGGGHHIIIIIIIIIJKLLLLMMNNNNNNOOOOOOOOPPQQRRRRRRSSSSTTTTTTUUUUVVWWXXYYYZZ";
  //String simon = "SIMON!!!";
	//int i=0;
	for(int x=0; x<4; x++){
   for(int y=0; y<2; y++){
	
    letters.add(new Letter(100+ x*200, y*(-200)- 100,alphabet.charAt(r.nextInt(alphabet.length())),0,30));
	//letters.add(new Letter(100+ x*200, y*(-200)- 100,simon.charAt(i),0,30));
	//i++;
   } 
  }
  drop = new DropSpace(100,height*2/3,6);
  circle = new DropCircle(width+300,height+300,300);
  circleV = new PVector(-1,-1);
  circleV.normalize();
  circleV.mult(35);
  dragged = null;
  letterSize = width/10;
  isAWord = false;
  loadDatabase();
  wordsUsed = new HashSet<String>();
  started = false;
  points = 0;
  nextPos = 0;
  already = false;
 
}

public void draw(){
  background(bkg);
  
  textAlign(RIGHT);
  textFont(f2,60);
  fill(80);
  text("word.",width-20,60);
  if(started){
      fill(120);
      if(already){
        text("you already got that ",width-170,60);
      }
      else if(isAWord){
          text("that's a ",width-165,60);
      }else{
        text("that's not a ",width-170,60);
      }

    
  }
  
  fill(120);
  textFont(f2,150);
  text(points,width-20,200);
  
  textFont(f,36);
  
  textAlign(LEFT);
  
  circle.render();
  
  drop.render();
  /*int wid = 0;
  fill(172);
  for(Character s : drop.val){
    text(s,100 + wid, height-70);
    wid += 36;
  }
  */

  
  //println(letters.size());
  /*
  for(Letter l : letters){
   l.render(); 
  }
  */
    int lettersRemoved = 0;
    boolean stopped = true;
   Iterator<Letter> itr = letters.iterator();
   while(itr.hasNext()){  
     Letter l = itr.next();
     l.render(); 
    if(abs(l.v.x) > 0 || abs(l.v.y) > 0){
     stopped = false; 
    }
    if(l.pos.y > height){
      lettersRemoved++;
      itr.remove();
      if(l.isIn != null){
        drop.val.set(l.index,'0');
        drop.currLetters.remove(l);
      }
    } 
  }
  if(lettersRemoved > 0){ //add new letters
    addNewLetters(lettersRemoved);
  }
  
    /*if(stopped && !mousePressed && circle.v.x == 0 && circle.v.y == 0){
     noLoop(); 
    }*/
  

}

public void mousePressed(){
  //loop();
  for(Letter l : letters){
    if(l.isMouseOver()){
     circle.v = new PVector(circleV.x,circleV.y);
     if(abs(circle.pos.x - circle.initPos.x) > .1f){
      circle.pos = new PVector(circle.initPos.x,circle.initPos.y);
     }
     dragged = l; 
     break;
    }
  }
}

public void mouseDragged(){
 if(dragged != null){
  dragged.pos.x = mouseX - letterSize/2;
  dragged.pos.y = mouseY - letterSize/2;
  redraw();
  }

}

public void mouseReleased(){
 if(dragged != null){
  if(dragged.isIn != null){
    dragged.isIn.val.set(dragged.index,'0');
   dragged.isIn = null;
   dragged.index = -1;
  }
  drop.dropCheck(dragged);
  
  //check for drop circle
  circle.dropCheck(dragged);
  
 }
 dragged = null;
 isAWord = drop.checkWord(); 
 circle.v = new PVector(-1*circleV.x,-1*circleV.y);
 redraw();
 //noLoop();
}

public void addNewLetters(int lettersRemoved){
    for(int x=0; x < 4; x++){
       for(int y=0; y<2; y++){
        if(lettersRemoved <= 0){
          break; 
        }
        lettersRemoved--;
        nextPos++;
        if(nextPos > 4){
         nextPos = 0; 
        }
        letters.add(new Letter(100+ (x+nextPos)*200, y*(-200)- 100,alphabet.charAt(r.nextInt(alphabet.length())),0,30));

   } 
  }
}

public void loadDatabase(){
	
  words = new HashSet<String>();
	
	try {
		ObjectInputStream input = new ObjectInputStream(createInput("dict"));
			 			words =  (HashSet<String>)input.readObject();
			 		} catch (Exception e) {
			 			System.out.println("Something bad happened...");
			 		}
					/*
					  BufferedReader br = null;
					  String strLine;
					  try {
					  //FileInputStream fstream = new FileInputStream("/Users/Simon/Documents/Processing/wordgame/dict.txt");
					  InputStream fstream = createInput("dict");
					  DataInputStream in = new DataInputStream(fstream);
					  br = new BufferedReader(new InputStreamReader(in));
					  //br = createReader("dict.txt")	
					  *		
					while ((strLine = br.readLine()) != null)   {

							words.add(strLine);
						}

						in.close();

						} catch (Exception e) {
							e.printStackTrace();
						}	
					*/
	//make new object file

	/* try{{{{{}}}}
		ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("/Users/Simon/Documents/Processing/wordgame/dict"));
		output.writeObject(words);
		output.close();
  		} catch (Exception e) {
			e.printStackTrace();
		}
		*/
  
}

class Letter{
  PVector pos,v; 
  char ch; //the letter it represents, could possibly be more than one letter
  int c;
  DropSpace isIn;
  int index,uses;
  
  
  Letter(float x, float y, char ch){
   pos = new PVector(x,y);
   this.ch = ch; 
   c = defaultLetterColor;
   isIn = null;
   index = -1;
   v = new PVector(0,0);
   uses = 0;
  }
  
  Letter(float x, float y, char ch, float vx, float vy){
   pos = new PVector(x,y);
   this.ch = ch; 
   c = defaultLetterColor;
   isIn = null;
   index = -1;
   v = new PVector(vx,vy);
   uses = 0;
  }
  
  public boolean isMouseOver(){
    if(mouseX >= pos.x && mouseX <= pos.x + letterSize && mouseY >= pos.y && mouseY <= pos.y + letterSize){
     return true; 
    }
    return false;
    
  }
  
  public void render(){
    //println(v);
    if(uses >= 3){
     v.y = 30; 
     //loop();
    }
    
    if(abs(v.x) < .01f){
     v.x = 0; 
     //noLoop();
    }
    if(abs(v.y) < .01f){
     v.y = 0; 
     //noLoop();
    }
    if(abs(v.x) > 0 || abs(v.y) > 0){
     pos.add(v);
     v.mult(damp);
     //loop();
    } 
    if(uses == 0)
      fill(237,201,81,172);
    else if(uses == 1)
      fill(235,104,65,172);
    else
      fill(204,51,63,172);

    rect(pos.x,pos.y,letterSize,letterSize,10);
    fill(80);
    textFont(f,letterSize/1.2f);
    if(ch == 'W' || ch == 'M'){
      text(ch,pos.x+letterSize/4.5f-10,pos.y+letterSize/1.3f);
    }else
    text(ch,pos.x+letterSize/4.5f,pos.y+letterSize/1.3f);
  }
  
}

class DropSpace{
  PVector pos;
  ArrayList<Character> val;
  HashSet<Letter> currLetters;
  int numLetters;
  
   DropSpace(float x, float y, int num){
    pos = new PVector(x,y);
    numLetters = num; //number of letters
    val = new ArrayList<Character>(num);
    for(int i=0; i<num; i++){
      val.add('0');
    } 
    currLetters = new HashSet<Letter>();
   }
   
   public boolean checkWord(){
     String s = "";
     for(Character ch : val){
      if(ch != '0'){
       s+=ch;
      } 
     }
     boolean is = words.contains(s);
     boolean used = wordsUsed.contains(s);
     //boolean is = true;
     //boolean used = true;
	if(!used && s.equals("SIMON")){
		points+=999999999;
		wordsUsed.add(s);
	}
     if(is){
       wordsUsed.add(s);
     }
     if(used){
      //started = false;
      already = true; 
     }else{
      already = false; 
     }
     if(is && !used){
      points += s.length()*s.length();
      for( Letter l : currLetters){
       l.uses++;
      }
      return true;
     }
     return false;
   }
   
   public boolean dropCheck(Letter l){
     float w = dropPadding + (letterSize + dropPadding) * numLetters;
     float h = letterSize + dropPadding*2;
     if(l.pos.x <= pos.x + w && l.pos.x + letterSize >= pos.x && l.pos.y + letterSize >= pos.y && l.pos.y <= pos.y + h){
       int position = PApplet.parseInt((l.pos.x-pos.x+letterSize/2)/w*numLetters);
       if(position < 0){
        position = 0; 
       }
       if(position < numLetters && val.get(position) =='0'){
         l.pos.x = pos.x + dropPadding + (letterSize + dropPadding) * position;
         l.pos.y = pos.y + dropPadding;
         val.set(position,l.ch);
         l.isIn = this;
         l.index = position;
         currLetters.add(l);
         started = true;
         return true;
       } 
     }
     currLetters.remove(l);
     return false;
   }
   
   public void render(){
     fill(defaultDropSpaceColor);
     float wid = dropPadding + (letterSize + dropPadding) * numLetters;
     rect(pos.x,pos.y,wid,letterSize + dropPadding*2,10);
     
   }
  
  
}

//for throwing away tiles
class DropCircle{
  PVector pos,v,initPos;
  float rad;
  
  DropCircle(float x, float y, float r){
    initPos = new PVector(x,y);
    pos = new PVector(x,y);
    v = new PVector(0,0);
    rad = r;
  }
  
  public boolean dropCheck(Letter l){
     if(dist(pos.x,pos.y,l.pos.x + letterSize, l.pos.y+letterSize) < rad/2){
        addNewLetters(0);
        l.v = new PVector(-1*circleV.x,-1*circleV.y);
        points -= 10;
        return true;
     }
     return false;
   }
  
  public void render(){
    if(abs(v.x) < .01f){
     v.x = 0; 
    }
    if(abs(v.y) < .01f){
     v.y = 0; 
    }
    if(abs(v.x) > 0 || abs(v.y) > 0){
     pos.add(v);
     v.mult(damp);
    } 
   fill(220); 
   ellipse(pos.x,pos.y,rad,rad);
  }
  
}














  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "wordgame" });
  }
}
